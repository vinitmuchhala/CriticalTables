<!--statistics-->
<div id="statistics">
        
        <h3>Random Graph Set #1</h3>
        
        <table class="pie line area bar">
            <caption>2009 Student Marks - Sample Set #1</caption>
            <thead>
                <tr>
                    <td></td>
                    <th>Physics</th>
                    <th>Chemistry</th>
                    <th>Maths</th>
                    <th>B.E.E</th>
                    <th>Mechanics</th>
                    <th>C++</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Mary</th>
                    <td>190</td>
                    <td>0</td>
                    <td>40</td>
                    <td>120</td>
                    <td>30</td>
                    <td>70</td>
                </tr>
                <tr>
                    <th>Tom</th>
                    <td>3</td>
                    <td>40</td>
                    <td>30</td>
                    <td>45</td>
                    <td>35</td>
                    <td>49</td>
                </tr>
                <tr>
                    <th>Brad</th>
                    <td>10</td>
                    <td>180</td>
                    <td>10</td>
                    <td>85</td>
                    <td>25</td>
                    <td>79</td>
                </tr>
                <tr>
                    <th>Kate</th>
                    <td>40</td>
                    <td>80</td>
                    <td>90</td>
                    <td>25</td>
                    <td>15</td>
                    <td>119</td>
                </tr>
            </tbody>
        </table>
        

</div><!--statistics-->